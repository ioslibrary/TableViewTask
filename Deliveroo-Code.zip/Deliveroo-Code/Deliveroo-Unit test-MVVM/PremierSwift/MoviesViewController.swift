import UIKit

protocol APIResponseProtocol: AnyObject {
    func didReceiveResponse()
    func errorHandler(error: APIError)
}

final class MoviesViewController: UITableViewController {
    
    lazy private var productVM = MoviesViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = LocalizedString(key: "movies.title")
        
        tableView.dm_registerClassWithDefaultIdentifier(cellClass: MovieCell.self)
        tableView.rowHeight = UITableView.automaticDimension
        
        tableView.refreshControl = UIRefreshControl()
        tableView.refreshControl?.addTarget(self, action: #selector(refreshAction), for: .valueChanged)
        self.productVM.delegate = self
        self.productVM.fetchMovies()
    }
    @objc private func refreshAction() {
        self.productVM.fetchMovies()
    }
    
    func showError() {
        let alertController = UIAlertController(title: "", message: LocalizedString(key: "movies.load.error.body"), preferredStyle: .alert)
        let alertAction = UIAlertAction(title: LocalizedString(key: "movies.load.error.actionButton"), style: .default, handler: nil)
        alertController.addAction(alertAction)
        present(alertController, animated: true, completion: nil)
    }
}

// MARK: - UITableViewDataSource
extension MoviesViewController {
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return productVM.numberOfMovies()
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: MovieCell = tableView.dm_dequeueReusableCellWithDefaultIdentifier()
        
        let movie = self.productVM.movie(at: indexPath.row)
        cell.configure(movie)
        return cell
    }
}

// MARK: - UITableViewControllerDelegate
extension MoviesViewController {
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let movie = self.productVM.movie(at: indexPath.row)
        let viewController = MovieDetailsViewController(movie: movie)
        self.navigationController?.pushViewController(viewController, animated: true)
    }
}

// MARK: API response
extension MoviesViewController: APIResponseProtocol {
    func errorHandler(error: APIError) {
        DispatchQueue.main.async {
            // show error message
            self.tableView.refreshControl?.endRefreshing()
            self.showError()
        }
    }
    func didReceiveResponse() {
        DispatchQueue.main.async {
            self.tableView.reloadData()
            self.tableView.refreshControl?.endRefreshing()
        }
    }
}
