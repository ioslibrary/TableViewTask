import UIKit

final class MoviesViewController: UITableViewController {
    
    var isSearch: Bool = false
    
    var movies = [Movie]() {
        didSet {
            tableView.reloadSections(IndexSet(integer: 0), with: .automatic)
        }
    }
    var searchedMovies = [Movie]() {
        didSet {
            tableView.reloadSections(IndexSet(integer: 0), with: .automatic)
        }
    }

    lazy var searchBar:UISearchBar = UISearchBar()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = LocalizedString(key: "movies.title")
        
        tableView.dm_registerClassWithDefaultIdentifier(cellClass: MovieCell.self)
        tableView.rowHeight = UITableView.automaticDimension
        
        refreshControl = UIRefreshControl()
        refreshControl?.addTarget(self, action: #selector(fetchData), for: .valueChanged)
        
        configureSearchBar()
        searchBar.delegate = self
        fetchData()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        navigationItem.titleView = searchBar
        navigationItem.hidesSearchBarWhenScrolling = false
        definesPresentationContext = true
    }
    
    func searchResults(search searchText: String) {
        let request = Request<Page<Movie>>(method: Method.get, path: "/search/movie", pars: ["query": searchText])
        APIManager.shared.execute(request, completion: { result in
            if case .success(let page) = result {
                DispatchQueue.main.async {
                    self.searchedMovies = page.results
                }
            }
        })
    }
    
    @objc func fetchData() {
        APIManager.shared.execute(Movie.topRated) { [weak self] result in
            switch result {
            case .success(let page):
                DispatchQueue.main.async {
                    self?.refreshControl?.endRefreshing()
                    self?.movies = page.results
                }
            case .failure:
                DispatchQueue.main.async {
                    self?.refreshControl?.endRefreshing()
                    self?.showError()
                }
            }
        }
    }
    
    func showError() {
        let alertController = UIAlertController(title: "", message: LocalizedString(key: "movies.load.error.body"), preferredStyle: .alert)
        let alertAction = UIAlertAction(title: LocalizedString(key: "movies.load.error.actionButton"), style: .default, handler: nil)
        alertController.addAction(alertAction)
        present(alertController, animated: true, completion: nil)
    }
    
    private func configureSearchBar() {
        searchBar.setTextField()
        searchBar.setLeftImage(UIImage(named: "Search"))
        searchBar.setUI()
    }
}

// MARK: - UITableViewDataSource
extension MoviesViewController {
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isSearch {
            return searchedMovies.count
        }
        return movies.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: MovieCell = tableView.dm_dequeueReusableCellWithDefaultIdentifier()
        
        let movie: Movie
        if isSearch {
            movie = searchedMovies[indexPath.row]
        }
        else {
            movie = movies[indexPath.row]
        }
        
        cell.configure(movie)
        
        return cell
    }
}

// MARK: - UITableViewControllerDelegate
extension MoviesViewController {
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let movie: Movie
        if isSearch {
            movie = searchedMovies[indexPath.row]
        }
        else {
            movie = movies[indexPath.row]
        }
        let viewController = MovieDetailsViewController(movie: movie)
        self.navigationController?.pushViewController(viewController, animated: true)
    }
}
extension MoviesViewController: UISearchBarDelegate{
    //MARK: UISearchbar delegate
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.count == 0 {
            isSearch = false
            fetchData()
        } else {
            Debounce<String>.input(searchText, comparedAgainst: searchBar.text ?? "") {_ in
                self.isSearch = true
                self.searchResults(search: searchText)
            }
        }
    }
}
