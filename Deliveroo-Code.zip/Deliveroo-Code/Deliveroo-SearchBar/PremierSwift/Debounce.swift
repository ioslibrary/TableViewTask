//Basic premise is that we are just delaying the processing of the input text by 0.5 seconds.
//At that time, we compare the string we got from the event with the current value of the search bar.
//If they match, we assume that the user has paused entering text,
// and we proceed with the filtering operation.
//
// As it is generic, it works with any type of equatable value.

import Dispatch

class Debounce<T: Equatable> {

    private init() {}

    static func input(_ input: T,
                      comparedAgainst current: @escaping @autoclosure () -> (T),
                      perform: @escaping (T) -> ()) {

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            if input == current() {
                perform(input)
            }
        }
    }
}
