import UIKit

extension UISearchBar {
    func setLeftImage(_ image: UIImage?) {
        guard let image = image else {
            searchTextField.leftView = nil
            return
        }
        let imageView = UIImageView(image: image)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.widthAnchor.constraint(equalToConstant: 24).isActive = true
        imageView.heightAnchor.constraint(equalToConstant: 24).isActive = true
        imageView.tintColor = tintColor
        searchTextField.leftView = imageView
    }
    
    func setTextField() {
        let searchTextField = self.searchTextField
        searchTextField.attributedPlaceholder = NSAttributedString(string: "Search", attributes: [.font: UIFont.Body.medium, .foregroundColor: UIColor.Text.charcoal])
        searchTextField.font = UIFont(name: "Poppins-Regular", size: 16)
        searchTextField.backgroundColor = UIColor(red: 248 / 255.0, green: 248 / 255.0, blue: 248 / 255.0, alpha: 1)
        searchTextField.borderStyle = .none
        searchTextField.layer.borderColor = UIColor.black.withAlphaComponent(0.08).cgColor
        searchTextField.layer.borderWidth = 1.0
        searchTextField.layer.cornerRadius = 8
    }
    
    func setUI() {
        self.barTintColor = .clear
        self.setImage(UIImage(named: "Filter"), for: .bookmark, state: .normal)
        self.showsBookmarkButton = true
        self.tintColor = UIColor.Brand.popsicle40
    }
}
