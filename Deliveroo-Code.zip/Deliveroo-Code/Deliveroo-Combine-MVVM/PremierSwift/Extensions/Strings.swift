import Foundation

// swiftlint:disable:next identifier_name
func LocalizedString(key: String) -> String {
    return NSLocalizedString(key, comment: "")
}
