//
//  MoviesViewModel.swift
//  PremierSwift
//
//  Created by jitendra kumar on 12/2/22.
//  Copyright © 2022 Deliveroo. All rights reserved.
//

import Foundation

class MoviesViewModel {
    
    var movieResult: Page<Movie>?
    private var movieWebService: APIManager
    weak var delegate: APIResponseProtocol?
    
    init() {
        self.movieWebService = APIManager()
    }
    func movie(at index: Int) -> Movie {
        return (movieResult?.results[index])!
    }
    
    func numberOfMovies() -> Int {
        return movieResult?.results.count ?? 0
    }
    
    func fetchMovies() {
        self.movieWebService.execute(Movie.topRated) { [weak self] result in
            guard let this = self else { return }
            switch result {
            case .success(let page):
                self?.movieResult = page
                this.delegate?.didReceiveResponse()
            case .failure:
                this.delegate?.errorHandler(error: .networkError)
            }
        }
    }
}
