//
//  SimilarMovieCell.swift
//  PremierSwift
//
//  Created by Administrator on 11/26/22.
//  Copyright © 2022 Deliveroo. All rights reserved.
//

import UIKit

class SimilarMovieCell: UICollectionViewCell {
    let columnSpacing: CGFloat = 16
    let posterSize = CGSize(width: 110, height: 170)
    
    let coverImage = UIImageView()
    let tagView = TagView()
    let titleLabel = UILabel()
    let descriptionLabel = UILabel()
    
    let textStackView = UIStackView()
    let imageStackView = UIStackView()
    let containerStackView = UIStackView()
    
    override var isSelected: Bool{
      didSet{
        if self.isSelected
        {
            tagView.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
          
        }
        else
        {
         tagView.transform = CGAffineTransform.identity

          
        }
      }
    }
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    override func layoutSubviews() {
        commonInit()

    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    private func commonInit() {
        layoutMargins = UIEdgeInsets(top: 16, left: 16, bottom: 16, right: 16)
        titleLabel.font = UIFont.Body.smallSemiBold
        titleLabel.textColor = UIColor.Text.charcoal
        //titleLabel.numberOfLines = 0
        //titleLabel.lineBreakMode = .byWordWrapping
        
        descriptionLabel.font = UIFont.Body.smallFont
        descriptionLabel.textColor = UIColor.black
        descriptionLabel.numberOfLines = 0
        descriptionLabel.lineBreakMode = .byWordWrapping
        
        coverImage.contentMode = .scaleAspectFill
        coverImage.layer.cornerRadius = 8
        coverImage.layer.masksToBounds = true
        
        textStackView.spacing = 4
        textStackView.alignment = .leading
        textStackView.axis = .vertical
        
        imageStackView.alignment = .fill
        imageStackView.axis = .vertical
        
        containerStackView.spacing = columnSpacing
        containerStackView.alignment = .top
        containerStackView.translatesAutoresizingMaskIntoConstraints = false
        
        setupViewsHierarchy()
        setupConstraints()
    }
    
    func setupViewsHierarchy() {
        contentView.addSubview(containerStackView)
        imageStackView.dm_addArrangedSubviews(coverImage)
        textStackView.dm_addArrangedSubviews(titleLabel, descriptionLabel)
        self.containerStackView.axis = .vertical

        containerStackView.dm_addArrangedSubviews(imageStackView,textStackView,tagView)
    }
    
    func setupConstraints() {
        
        NSLayoutConstraint.activate([
            containerStackView.leadingAnchor.constraint(equalTo: contentView.layoutMarginsGuide.leadingAnchor),
            containerStackView.trailingAnchor.constraint(equalTo: contentView.layoutMarginsGuide.trailingAnchor),
            containerStackView.topAnchor.constraint(equalTo: contentView.layoutMarginsGuide.topAnchor),
            containerStackView.bottomAnchor.constraint(equalTo: contentView.layoutMarginsGuide.bottomAnchor),
            
            coverImage.widthAnchor.constraint(equalToConstant: posterSize.width),
            coverImage.heightAnchor.constraint(equalToConstant: posterSize.height)
        ])
    }
    
    func configure(_ movie: Movie) {
        titleLabel.text = movie.title
        descriptionLabel.text = LocalizedString(key: "similarmovie.load.error.genrename")
        tagView.configure(.rating(value: movie.voteAverage))
        if let path = movie.posterPath {
            coverImage.contentMode = .scaleAspectFill
            coverImage.dm_setImage(posterPath: path)
        } else {
            coverImage.image = nil
        }
    }
    override func prepareForReuse() {
        super.prepareForReuse()
    }
}
