//
//  MoviesViewControllerTest.swift
//  PremierSwiftTests
//
//  Created by jitendra kumar on 11/27/22.
//  Copyright © 2022 Deliveroo. All rights reserved.
//

import XCTest
@testable import PremierSwift

final class MoviesViewControllerTest: XCTestCase {

    var viewControllerUnderTest: MoviesViewController!
    var movieViewModelUnderTest: APIManager!
    
    override func setUp() {
        super.setUp()
        
        self.viewControllerUnderTest = MoviesViewController()
        self.movieViewModelUnderTest = APIManager()
        
        self.viewControllerUnderTest.loadView()
        self.viewControllerUnderTest.viewDidLoad()
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        viewControllerUnderTest = nil
        movieViewModelUnderTest = nil
        super.tearDown()
    }
    
    func testHasATableView() {
        XCTAssertNotNil(viewControllerUnderTest.tableView)
    }
    
    func testTableViewHasDelegate() {
        XCTAssertNotNil(viewControllerUnderTest.tableView.delegate)
    }
    
    func testTableViewConfromsToTableViewDelegateProtocol() {
        XCTAssertTrue(viewControllerUnderTest.conforms(to: UITableViewDelegate.self))
        XCTAssertTrue(viewControllerUnderTest.responds(to: #selector(viewControllerUnderTest.tableView(_:didSelectRowAt:))))
    }
    
    func testTableViewHasDataSource() {
        XCTAssertNotNil(viewControllerUnderTest.tableView.dataSource)
    }
    
    func testTableViewConformsToTableViewDataSourceProtocol() {
        XCTAssertTrue(viewControllerUnderTest.conforms(to: UITableViewDataSource.self))
        XCTAssertTrue(viewControllerUnderTest.responds(to: #selector(viewControllerUnderTest.numberOfSections(in:))))
        XCTAssertTrue(viewControllerUnderTest.responds(to: #selector(viewControllerUnderTest.tableView(_:numberOfRowsInSection:))))
        XCTAssertTrue(viewControllerUnderTest.responds(to: #selector(viewControllerUnderTest.tableView(_:cellForRowAt:))))
    }
    
//    func testTableViewCellHasReuseIdentifier() {
//        viewControllerUnderTest.productVM.movieResult?.results = [Movie(id: 1, title: "20th Century Girl", overview: "Some decription", posterPath: "https://image.tmdb.org/t/p/w185/fcFz2xEZodKOxHDn9DazxPYHDSc.jpg", voteAverage: 8.1)]
//        let cell = viewControllerUnderTest.tableView(viewControllerUnderTest.tableView, cellForRowAt: IndexPath(row: 0, section: 0)) as? MovieCell
//        let actualReuseIdentifer = cell?.reuseIdentifier
//        let expectedReuseIdentifier = "MovieCell"
//        XCTAssertEqual(actualReuseIdentifer, expectedReuseIdentifier)
//    }
//
//    func testTableCellHasCorrectLabelText() {
//        viewControllerUnderTest.productVM.movieResult?.results = [Movie(id: 1, title: "20th Century Girl", overview: "Some decription", posterPath: "https://image.tmdb.org/t/p/w185/fcFz2xEZodKOxHDn9DazxPYHDSc.jpg", voteAverage: 8.1)]
//        let cell0 = viewControllerUnderTest.tableView(viewControllerUnderTest.tableView, cellForRowAt: IndexPath(row: 0, section: 0)) as? MovieCell
//        XCTAssertEqual(cell0?.titleLabel.text, "20th Century Girl")
//    }
    
    func test_top_rated_movies_success_request() {
        let expectations = expectation(description: "WebService Response")
        
        let movie_request = Request<[Movie]>(method: Method.get, path: "/movie/top_rated")
        let request_url = URL(APIManager.shared.host, APIManager.shared.apiKey, movie_request)
        XCTAssertEqual(request_url.absoluteString, "https://api.themoviedb.org/3/movie/top_rated?api_key=e4f9e61f6ffd66639d33d3dde7e3159b")
        
        movieViewModelUnderTest.execute(movie_request, completion: { result in
            if case .success(let movies) = result {
                XCTAssertTrue(movies.count > 0)
            }
            expectations.fulfill()
        })
        waitForExpectations(timeout: 5) { error in
            if let error = error {
                print("Error: \(error.localizedDescription)")
            }
        }
    }
    func test_top_rated_movies_failure_request() {
        let expectations = expectation(description: "WebService Response")
        
        let movie_request = Request<[Movie]>(method: Method.get, path: "/movie/top_rated_")
        let request_url = URL(APIManager.shared.host, APIManager.shared.apiKey, movie_request)
        XCTAssertEqual(request_url.absoluteString, "https://api.themoviedb.org/3/movie/top_rated_?api_key=e4f9e61f6ffd66639d33d3dde7e3159b")
        
        movieViewModelUnderTest.execute(movie_request, completion: { result in
            if case .failure(let failure) = result {
                XCTAssertEqual(failure, APIError.parsingError)
            }
            expectations.fulfill()
        })
        waitForExpectations(timeout: 5) { error in
            if let error = error {
                print("Error: \(error.localizedDescription)")
            }
        }
    }
}
