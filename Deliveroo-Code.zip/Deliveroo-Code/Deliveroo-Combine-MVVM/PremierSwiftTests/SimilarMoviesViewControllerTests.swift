//
//  SimilarMoviesViewControllerTests.swift
//  PremierSwiftTests
//
//  Created by jitendra kumar on 11/28/22.
//  Copyright © 2022 Deliveroo. All rights reserved.
//

import XCTest
@testable import PremierSwift

final class SimilarMoviesViewControllerTests: XCTestCase {

    func test_similar_movies_success_request() {
        let expectations = expectation(description: "WebService Response")
        
        let movie_request = Request<[Movie]>(method: Method.get, path: "/movie/851644/similar")
        let request_url = URL(APIManager.shared.host, APIManager.shared.apiKey, movie_request)
        XCTAssertEqual(request_url.absoluteString, "https://api.themoviedb.org/3/movie/851644/similar?api_key=e4f9e61f6ffd66639d33d3dde7e3159b")
        
        APIManager.shared.execute(movie_request, completion: { result in
            if case .success(let movies) = result {
                XCTAssertTrue(movies.count > 0)
            }
            expectations.fulfill()
        })
        waitForExpectations(timeout: 5) { error in
            if let error = error {
                print("Error: \(error.localizedDescription)")
            }
        }
    }
    
    func test_similar_movies_failure_request() {
        let expectations = expectation(description: "WebService Response")
        
        let movie_request = Request<[Movie]>(method: Method.get, path: "/movie/851644/similar_")
        let request_url = URL(APIManager.shared.host, APIManager.shared.apiKey, movie_request)
        XCTAssertEqual(request_url.absoluteString, "https://api.themoviedb.org/3/movie/851644/similar_?api_key=e4f9e61f6ffd66639d33d3dde7e3159b")
        
        APIManager.shared.execute(movie_request, completion: { result in
            if case .failure(let failure) = result {
                print(failure)
            }
            expectations.fulfill()
        })
        waitForExpectations(timeout: 5) { error in
            if let error = error {
                print("Error: \(error.localizedDescription)")
            }
        }
    }

}
