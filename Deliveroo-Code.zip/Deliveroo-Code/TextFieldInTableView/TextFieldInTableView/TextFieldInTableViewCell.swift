//
//  TextFieldInTableViewCell.swift
//  TextFieldInTableView
//
//  Created by Jitendra Kumar (Cognizant) on 25/03/21.
//

import UIKit

class TextFieldInTableViewCell: UITableViewCell {

    @IBOutlet weak var textFieldInTableViewCell: UITextField!
    var ClousureTextFieldActionHandler:((_ sender: UITextField) -> Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    @IBAction func textFieldEditingChanged(_ sender: UITextField) {
        if self.ClousureTextFieldActionHandler != nil {
            self.ClousureTextFieldActionHandler!(sender)
        }
    }


    func setParam(val: TextFieldModel) {
        textFieldInTableViewCell.text = val.value
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
