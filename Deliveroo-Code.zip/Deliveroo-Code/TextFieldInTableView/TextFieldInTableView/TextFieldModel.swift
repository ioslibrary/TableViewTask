//
//  TextFieldModel.swift
//  TextFieldInTableView
//
//  Created by Jitendra Kumar (Cognizant) on 25/03/21.
//

import Foundation

class TextFieldModel {
    var id: Int = 0
    var value: String?
    var placeholder: String? 
}
