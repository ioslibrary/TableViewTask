//
//  ViewController.swift
//  TextFieldInTableView
//
//  Created by Jitendra Kumar (Cognizant) on 24/03/21.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var tableVw: UITableView!
    var valueArray = [TextFieldModel]()

    override func viewDidLoad() {
        super.viewDidLoad()

        for i in 0..<20 {
            let model = TextFieldModel()
            model.id = i + 1
            model.placeholder = "Type here.."
            model.value = ""
            valueArray.append(model)
        }

        let xib = UINib(nibName: "TextFieldInTableViewCell", bundle: nil)
        self.tableVw.register(xib, forCellReuseIdentifier: "TextFieldInTableViewCellIdentifier")
        self.tableVw.dataSource = self
        self.tableVw.delegate = self
        self.tableVw.reloadData()
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       let cell = tableView.dequeueReusableCell(withIdentifier: "TextFieldInTableViewCellIdentifier", for: indexPath) as! TextFieldInTableViewCell
       cell.selectionStyle = .none
        print(valueArray[indexPath.row].value ?? "jk", indexPath.row)
       cell.setParam(val: valueArray[indexPath.row])

        cell.ClousureTextFieldActionHandler = { sender in
            self.valueArray[indexPath.row].value = sender.text
            for i in 0..<self.valueArray.count {
                print(self.valueArray[i].value ?? "")
            }

        }

       return cell
   }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return 20
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }

}



